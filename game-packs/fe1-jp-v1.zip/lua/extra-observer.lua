-- Confirm changes in a second sample; never consult future reinforcement tables.
local module={}
function module.new()
    local self={pending={}}
    function self:reset() self.pending={} end
    function self:sample(host,frame,old,state)
        if not old or not state or old.state.chapter~=state.chapter or state.turn<old.state.turn then self:reset(); return end
        local previous=old.state
        local bykey,before={},{}
        for _,u in ipairs(state.units) do bykey[u.key]=u end
        for _,u in ipairs(previous.units) do before[u.key]=u end
        local scene=state.scene or {}
        local fight=scene.fight_class_raw or 0
        local ready=not state.dialogue and (scene.menu_mode_raw or 0)==0 and not (fight>=1 and fight<=24)
        local waiting={}
        for _,p in ipairs(self.pending) do
            if p.check(state,bykey) and frame-p.frame<=600 then
                if ready then p.event.after_frame=frame; host:append(p.event)
                else waiting[#waiting+1]=p end
            end
        end
        self.pending=waiting
        local function defer(event,check)
            event.before_frame=old.frame
            self.pending[#self.pending+1]={event=event,check=check,frame=frame}
        end
        local raw={}
        for _,r in ipairs(previous.enemy_records or {}) do raw[r.key]=r end
        for _,u in ipairs(state.units) do
            local prev=before[u.key]
            if u.side=="enemy" and u.hp>0 and not prev and previous.enemy_records then
                local r=raw[u.key]
                -- Reused defeated slots count; a temporarily hidden living record does not.
                if not r or (r.flag==0xff and r.hp==0) then
                    local key,pid=u.key,u.character_id
                    defer({type="enemy_appeared",unit_key=key,character_id=pid,side="enemy",x=u.x,y=u.y},
                        function(_,units) local v=units[key]; return v and v.character_id==pid and v.hp>0 end)
                end
            end
            if prev and prev.character_id==u.character_id and u.side=="player" then
                local key,pid=u.key,u.character_id
                if prev.class_id and u.class_id and prev.class_id~=u.class_id then
                    local jid=u.class_id
                    defer({type="class_changed",unit_key=key,character_id=pid,side="player",from=prev.class_id,to=jid},
                        function(_,units) local v=units[key]; return v and v.character_id==pid and v.class_id==jid end)
                end
                if prev.acted==false and u.acted==true and state.turn==previous.turn then
                    defer({type="unit_acted",unit_key=key,character_id=pid,side="player"},
                        function(_,units) local v=units[key]; return v and v.character_id==pid and v.acted==true end)
                end
            end
        end
        if previous.map_cells and state.map_cells and previous.map and state.map
            and previous.map.width==state.map.width and previous.map.height==state.map.height then
            for i,tile in ipairs(state.map_cells) do
                local prior=previous.map_cells[i]
                local kind=prior==0xa5 and tile==0xa9 and "village_destroyed"
                    or prior==0xab and tile==0xac and "chest_opened"
                if kind then
                    local index,value=i,tile
                    defer({type=kind,x=(i-1)%state.map.width,y=math.floor((i-1)/state.map.width)},
                        function(s) return s.map_cells and s.map_cells[index]==value end)
                end
            end
        end
    end
    return self
end
return module
