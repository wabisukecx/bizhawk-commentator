# FE1 game pack

Game-specific code and data for Fire Emblem: Shadow Dragon and the Blade of Light (Japanese version).

- `app/`: commentary adapter, runtime interpretation, names, translations and narration phrases.
- `lua/`: memory reader, text decoding, map differences and short-lived observation logs.
- `dev/`: FE1-only recording and replay tools, excluded from the runtime ZIP.

Build from the project root: `npm.cmd run game-pack -- build-all`.

The host loads only the generated ZIP. Removing `game-packs/fe1-jp-v1.zip` removes this game's automatic commentary after restart; there is no built-in fallback.

No game ROM image is included. Memory layout reference: StanHash/fe1, commit `9b2fd3a03347818a60afaf913f94c36de0d953ba`, including `include/sram.asm`, `include/structs/unit.asm` and `code/home/unit.asm`.

Observed-event additions: enemy roster appearances (including reuse of defeated slots), village destruction, chest opening, class changes and unacted-ally milestones. Map/roster changes require a second consistent sample outside menus/battles/dialogue and are discarded across missing state or timeline resets. No future reinforcement table is read. Healing-terrain wording reports location and HP recovery together without claiming a cause. Battle effectiveness uses the actual combat item index and the physical-weapon branch of `ComputeFightDamage`/`IsEffective`; attack speed and hit rate come from computed battle RAM. Automated tests cover these paths, but live gameplay timing and later chapters remain unverified.

For local read-only recording, launch the emulator with `scripts/start-bizhawk.ps1 -LuaScript ignore/game-pack-sources/fe1-jp-v1/dev/bridge-with-probe.lua` and the usual emulator/ROM arguments. Replay a recorded session with `node ignore/game-pack-sources/fe1-jp-v1/dev/verify-session.mjs`. Recordings stay under the project's ignored `captures/scene-probe/` folder. Development tools and this source folder are not distributed.
